-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Oct 06, 2016 at 10:47 PM
-- Server version: 5.5.42
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `keiths`
--
CREATE DATABASE IF NOT EXISTS `keiths` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `keiths`;

-- --------------------------------------------------------

--
-- Table structure for table `barbers`
--

CREATE TABLE `barbers` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `barber_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `barber_id`) VALUES
(1, 'Eric', 104),
(2, 'Dad', 104),
(3, 'George', 105),
(4, 'Tanya', 0),
(5, 'Eric', 117),
(6, 'Dad', 117),
(7, 'George', 118),
(8, 'Tanya', 0),
(9, 'Eric', 130),
(10, 'Dad', 130),
(11, 'George', 131),
(12, 'Tanya', 0),
(13, 'Eric', 143),
(14, 'Dad', 143),
(15, 'George', 144),
(16, 'Tanya', 0),
(17, 'Eric', 156),
(18, 'Dad', 156),
(19, 'George', 157),
(20, 'Tanya', 0),
(21, 'Eric', 169),
(22, 'Dad', 169),
(23, 'George', 170),
(24, 'Tanya', 0),
(25, 'Eric', 182),
(26, 'Dad', 182),
(27, 'George', 183),
(28, 'Tanya', 0),
(29, 'Eric', 195),
(30, 'Dad', 195),
(31, 'George', 196),
(32, 'Tanya', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barbers`
--
ALTER TABLE `barbers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barbers`
--
ALTER TABLE `barbers`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=201;
--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
